# -*- coding: utf-8 -*-
"""
Payment System
author: hobin;
email = '627227669@qq.com';
"""
import copy
import cv2
import sys
import time

import os

import gc

import qrcode
from PIL import Image
from PIL.ImageQt import ImageQt
from PyQt5.QtCore import QTimer, QThread, QIODevice, QObject, Qt
from PyQt5.QtGui import QImage
from PyQt5.QtMultimedia import QMediaPlayer
from PyQt5.QtWidgets import QMainWindow, QApplication, QWidget, QStackedLayout
# -----------------------------------------------------------------------------------------------
from qtMediaPlayer import MyMediaPlayer
from CameraLayout import CameraDialog
from ML_Model import Detection1_2_1, Detection2_3_2_klas, Detection1_multi_model_1
from ML_Model import Detection1_simulation, Detection2_simulation
from sqlThread import MyThread3_3_1
from QRcodeThread import MyThread5_3_1_1
from Weigher import Weigher3_1
from ConfiguringModule import MyConfig1
from LoggingModule import MyLogging1
from Selfcheck import necessaryCheck_linux
from ReminderLayout import ReminderWeight02
from UserGuide import UserGuide03_1linux01
from SerialPortConsole import SerialPortConsole
from SkuSysn import SkuSysnServer
from CommonView import MainWindow
from WxSDK import WxFaceSdk


class PaymentSystem_sherry(QObject):

    def __init__(self, **kwargs):
        super(PaymentSystem_sherry, self).__init__()
        # configuration
        self.myconfig = MyConfig1(cfg_path='Sherry2.cfg')

        # user guide
        if self.myconfig.data['operating_mode']['need_guide'] == '1':
            a = UserGuide03_1linux01(cfg_path='Sherry2.cfg')
            reply = a.exec()
            if reply != 0:
                sys.exit('Error happens in user guide, please start again')
            self.myconfig = MyConfig1(cfg_path='Sherry2.cfg')  # to refresh the configuration.

        # logging
        self.mylogging = MyLogging1(logger_name='hobin')
        self.mylogging.logger.info('------------------Sherry starts------------------------------------')


        # necessary check before Sherry works
        if self.myconfig.data['necessary_check']['check_required'] == '1':
            necessaryCheck_linux(**self.myconfig.data)

        # all file path configuration
        self.project_path = os.path.dirname(__file__)
        # the expected outcome is like './Images';
        self.image_path = os.path.join(self.project_path, 'Images')
        if not os.path.exists(self.image_path):
            os.makedirs(self.image_path)
        icon_path = os.path.join(self.image_path, 'payment.png')
        self.image_pay_success = os.path.join(self.image_path, 'pay_success.png')
        self.image_pay_error = os.path.join(self.image_path, 'pay_error.png')
        # the expected outcome is like './working_images';
        self.working_images_path = os.path.join(self.project_path, 'working_images')
        if not os.path.exists(self.working_images_path):
            os.makedirs(self.working_images_path)
        self.working_images_original_path = os.path.join(self.project_path, 'working_images_original')
        if not os.path.exists(self.working_images_original_path):
            os.makedirs(self.working_images_original_path)

        # other UI component
        # This reminder is currently used in sql_work5_sherry function.
        self.reminder_weight_wrong_status = False  # True indicates the reminder is visible.
        self.reminder_weight_wrong = ReminderWeight02()

        # media player
        self.media_player = MyMediaPlayer(self)

        # item camera
        if self.myconfig.data['operating_mode']['cam_path_used'] == '1':
            self.capture1 = cv2.VideoCapture(self.myconfig.data['cam_item']['cam_path'])
        else:
            self.capture1 = cv2.VideoCapture(int(self.myconfig.data['cam_item']['cam_num']))
        self.capture1.set(3, int(self.myconfig.data['cam_item']['width']))  # 3 indicates the width;
        self.capture1.set(4, int(self.myconfig.data['cam_item']['height']))  # 4 indicates the height;

        # item camera 2
        if self.myconfig.data['cam_item2']['is_used'] == '1':
            if self.myconfig.data['operating_mode']['cam_path_used'] == '1':
                self.capture3 = cv2.VideoCapture(self.myconfig.data['cam_item2']['cam_path'])
            else:
                self.capture3 = cv2.VideoCapture(int(self.myconfig.data['cam_item2']['cam_num']))
            self.capture3.set(3, int(self.myconfig.data['cam_item2']['width']))  # 3 indicates the width;
            self.capture3.set(4, int(self.myconfig.data['cam_item2']['height']))  # 4 indicates the height;
        else:
            if self.myconfig.data['ml_item']['multi_model_item'] == '1':
                sys.exit('Configuration problem: the camera used for the multi-camera ML Model is missing.')

        # showing the camera frame for items
        if self.myconfig.data['operating_mode']['show_cam_item'] == '1':
            self.camera_dialog = CameraDialog(camera_object=self.capture1)
            self.camera_dialog.show()

        # shopping timer
        # self.timer1 = QTimer(self)
        # self.timer1.setSingleShot(True)
        # self.timer1.timeout.connect(self.shopping_timer_work3_sherry)

        # weigher 2
        self.record_weight = 0.0
        self.weigher = Weigher3_1(**self.myconfig.data['weigher'])
        self.weigher.detect_plus.connect(self.weigher1_work1_sherry)
        self.weigher.empty.connect(self.weigher2_work4b_sherry)
        self.weigher.detect_changed.connect(self.weigher2_work4c_sherry)
        self.weigher.to_standby.connect(self.weigher_work19_sherry)

        # thread4 is about the SQL statement
        self.error_try_times_sql = 0
        self.group_info_dict = {}  # It is the first time to be introduced in Sherry.
        self.thread4 = MyThread3_3_1(parent=self, **self.myconfig.data['db'])
        self.thread4.finished.connect(self.sql_work5_sherry)
        self.thread4.group_dict_refresh.connect(self.sql_work27_sherry, type=Qt.BlockingQueuedConnection)  # to refresh the dictionary immediately;
        self.thread4.error_connection.connect(self.sql_error05)
        self.thread4.error_algorithm.connect(self.sql_error06)

        # thread5 is about the account detection
        self.user_name = None
        self.user_portrait = QImage()
        self.error_try_times_account = 0
        self.failed_detection_local_counter = 0
        self.failed_detection_multiple_counter = 0
        # self.thread5 = MyThread4_0_1_3(parent=self, **self.myconfig.data['account'])
        # self.thread5.freezing_gesture.connect(self.account_work16_sherry, type=Qt.BlockingQueuedConnection)
        # self.thread5.user_info_success.connect(self.account_work6_sherry)
        # self.thread5.upload_img.connect(self.account_work15_sherry)
        # self.thread5.timeout_http.connect(self.account_error01)
        # self.thread5.connection_error.connect(self.account_error01)
        # self.thread5.error.connect(self.account_error01)
        # self.thread5.failed_detection_web_sherry.connect(self.account_work7_sherry)
        # self.thread5.failed_detection_local.connect(self.account_work17_sherry)
        # self.thread5.failed_detection_multiple.connect(self.account_work18_sherry)

        # thread6 is about the QR code thread
        self.icon = Image.open(icon_path)
        self.icon_w, self.icon_h = self.icon.size
        self.order_link = None
        self.thread6 = MyThread5_3_1_1(parent=self, **self.myconfig.data['order'])
        self.thread6.finished.connect(self.order_work8_sherry02)
        self.thread6.timeout_network.connect(self.order_error04)
        self.thread6.error.connect(self.order_error07)

        # thread8 is about the gesture-pay thread
        self.error_try_times_gesture_pay = 0
        # self.thread8 = MyThread7_1(**self.myconfig.data['gesture_pay'])
        # self.thread8.finished_error.connect(self.gesture_pay_work12)
        # self.thread8.timeout_http.connect(self.gesture_pay_error02)
        # self.thread8.connection_error.connect(self.gesture_pay_error02)
        # self.thread8.error.connect(self.gesture_pay_error02)
        # self.thread8.network_error.connect(self.gesture_pay_error08)

        # thread9 is about the websocket thread
        self.transaction_not_end_status = True
        self.pay_clear_by_gesture = True  # just used for upload image
        # self.thread9 = MyThread8_3(**self.myconfig.data['websocket'])
        # self.thread9.payclear_success.connect(self.websocket_work11_sherry)
        # self.thread9.payclear_failure.connect(self.websocket_work12)
        # self.thread9.opendoor.connect(self.websocket_work13)
        # self.thread9.payclear_success_code.connect(self.websocket_work25)
        # self.thread9.weight_clear.connect(self.websocket_work26)
        # self.thread9.start()
        # self.timer9 = QTimer()
        # self.timer9.timeout.connect(self.thread9.ping_timer)
        # self.timer9.start(60000)

        # thread10 is about the image-uploading thread
        self.gesture_img = None
        self.gesture_time = None
        self.items_img = None
        self.items_time = None
        self.user_img = None
        self.user_time = None
        self.error_try_times_image_upload = 0
        self.success_order_number = None
        # self.thread10 = MyThread9_1_1(**self.myconfig.data['image_upload'])
        # self.thread10.error.connect(self.image_upload_error03)

        # thread11 is about the item  quality thread
        self.error_try_times_item_quality = 0
        # self.thread11 = MyThread10(**self.myconfig.data['item_quality'])
        # self.thread11.network_error.connect(self.item_quality_error09)

        # ML Model for item detection
        if self.myconfig.data['simulation_item']['is_used'] == '1':
            self.thread0_1 = Detection1_simulation(camera_object=self.capture1, **self.myconfig.data['simulation_item'])
            self.thread0_1.detected.connect(self.ml_item_work2)
            # self.thread0_1.upload_img.connect(self.ml_item_work15b)
        elif self.myconfig.data['ml_item']['multi_model_item'] == '1':
            self.thread0_1 = Detection1_multi_model_1(camera_object=self.capture1, camera_object_2= self.capture3,
                                                     model2_used=True, parent=self, **self.myconfig.data['ml_item'])
            self.thread0_1.detected.connect(self.ml_item_work2)
            # self.thread0_1.upload_img.connect(self.ml_item_work15b)
        else:
            self.thread0_1 = Detection1_2_1(camera_object=self.capture1, parent=self, **self.myconfig.data['ml_item'])
            self.thread0_1.detected.connect(self.ml_item_work2)
            # self.thread0_1.upload_img.connect(self.ml_item_work15b)

        # ML Model for hand detection
        self.new_user_flag = True
        self.new_order_flag = True
        self.user_id = 'invalid'
        self.order_number = 'invalid'
        self.gesture_frame_location = {'x':0,'y':0,'length':0}
        self.gesture_frame_frozen_status = False
        # if self.myconfig.data['simulation_hand']['is_used'] == '1':
        #     self.thread0_0 = Detection2_simulation(parent=self, **self.myconfig.data['simulation_hand'])
        #     self.thread0_0.detected_gesture_info.connect(self.ml_gesture_work10_sherry02)
        #     self.thread0_0.upload_image.connect(self.ml_gesture_work15a)
        # else:
        #     self.thread0_0 = Detection2_3_2_klas(parent=self, **self.myconfig.data['ml_hand'])
        #     self.thread0_0.detected_gesture_info.connect(self.ml_gesture_work10_sherry02)
        #     self.thread0_0.upload_image.connect(self.ml_gesture_work15a)

        # 1, by my workmate, to refresh the database
        sysService = SkuSysnServer(dbHost= self.myconfig.data['db']['db_host'],
                                   user= self.myconfig.data['db']['db_user'],
                                   password= self.myconfig.data['db']['db_pass'],
                                   dbname= self.myconfig.data['db']['db_database'],
                                   store_id= self.myconfig.data['websocket']['storeid'],
                                   screen_id= self.myconfig.data['websocket']['screenid']
                                   )
        sysService.sysBindFinishSignal.connect(self.sysservice_work28_sherry)
        sysService.sysFinishSignal.connect(self.sysservice_work29_sherry)

        # 2, by my workmate, wechat app
        wechat_app = WxFaceSdk(faceUrl=self.myconfig.data['wechat_app']['faceurl'],
                               webSocketPort= self.myconfig.data['wechat_app']['websocketport'],
                               webSocketUrl= self.myconfig.data['wechat_app']['websocketurl'],
                               store_id= self.myconfig.data['wechat_app']['store_id'],
                               device_id = self.myconfig.data['wechat_app']['device_id'],
                               sub_appid = self.myconfig.data['wechat_app']['sub_appid'],
                               sub_mch_id = self.myconfig.data['wechat_app']['sub_mch_id'],
                               appid = self.myconfig.data['wechat_app']['appid'],
                               mch_id = self.myconfig.data['wechat_app']['mch_id']
                               )

        # 3, by my workmate, door controller
        self.door_controller = SerialPortConsole(serialinfo=self.myconfig.data['door_controller']['port_name'])
        # self.door_controller.outOpenDooSuccessByUser.connect(self.door_controller_work22)
        # self.door_controller.outOpenDooSuccess.connect(self.door_controller_work23)
        # self.door_controller.degaussSuccess.connect(self.door_controller_work24)

        # 4, by my workmate, layout management
        self.main_window_error_status = False
        if self.myconfig.data['operating_mode']['cam_path_used'] == '1':
            cam_user = self.myconfig.data['cam_user']['cam_path']
        else:
            cam_user = int(self.myconfig.data['cam_user']['cam_num'])
        self.main_window = MainWindow(cameraId= cam_user,
                                      cameraW= int(self.myconfig.data['cam_user']['width']),
                                      cameraH= int(self.myconfig.data['cam_user']['height']),
                                      sysService= sysService,
                                      wxsdk= wechat_app,
                                      serialConsole=self.door_controller
                                      )

        #
        del self.image_pay_success
        del self.image_pay_error
        self.mylogging.logger.info('------------------Sherry is ready to work------------------------------------')
        if self.weigher.serial.open(QIODevice.ReadOnly):
            self.mylogging.logger.info('the first connection of the weigher is successful.')
        else:
            self.mylogging.logger.info('the first connection of the weigher is failed.')
            sys.exit('the first connection of the weigher1 is failed.')


    def weigher1_work1_sherry(self):
        """
        Aim: switching the layout from standby to main;
        Requirement:
        stopping the CameraThread and starting the timer
        Optimization:
        when detecting the products, we can switch off the QTimer of StandbyLayout.
        But you don't know which one is working.
        """
        self.mylogging.logger.info('weigher1_work1_sherry begins')
        # if self.gesture_frame_frozen_status:
        #     # adding this since the account thread result might be no well matched user and you freeze the frame.
        #     self.main_window.stopHandGif()  # the main layout is restored manually
        #     self.gesture_frame_frozen_status = False
        # self.main_window.toSettlement()
        self.mylogging.logger.info(
            '--------------------------------Next transaction begins!---------------------------------********')
        # self.timer1.start(180000) # unit: millisecond, 24 hrs = 24*60*60*1000, 3 mins = 180000
        # If self.weigher.record_value = 0.0 is omitted, the ml item model actually does not starts when the standby layout is switched to the main layout;
        self.weigher.record_value = 0.0  
        self.weigher.serial.readyRead.connect(self.weigher.acceptData_order)
        # self.thread0_0.start()
        self.mylogging.logger.info('weigher1_work1_sherry ends')

    def ml_item_work2(self, result_detected):
        """
        The ML_item model says that the current result is not empty and it is different from the last result (Detection1_2_2 class).
        After the result of detection is done, we run the thread4 to use the result and query the database;
        After the querying, thread4 initiate the sql_work5_sherry() to refresh the GUI;
        :param result_detected: a list;
        :return: a list of detected product;
        """
        self.thread4.detected_result = result_detected
        self.thread4.start()

    def weigher2_work4b_sherry(self):
        """
        This function is initialized by the empty signal of self.weigher2;
        This function is to clear the information about the order since the current weight is zero.
        The self.weigher2 still works when this function is executed.
        """
        self.mylogging.logger.info('weigher2_work4b_sherry begins')
        self.main_window.cleanCommodity()
        self.main_window.setSumPrice.emit('0')
        self.order_number = 'invalid'
        self.new_order_flag = True
        self.thread0_1.last_result = []  # the communication between weigher and the ML Model for the ShoppingList Layout.
        self.reminder_weight_wrong.label1.setText('The current weight is 0.')
        if not self.reminder_weight_wrong_status and self.myconfig.data['operating_mode']['weight_error'] == '1':
            self.reminder_weight_wrong.setVisible(True)
            self.reminder_weight_wrong_status = True
        if self.main_window_error_status and self.myconfig.data['operating_mode']['normal_error'] == '1':
            self.main_window.hideErrorInfo()
            self.main_window_error_status = False
        # if self.timer1.isActive() and self.transaction_not_end_status:
        #     self.timer1.start(5000)
        self.mylogging.logger.info('weigher2_work4b_sherry ends')

    def weigher2_work4c_sherry(self, record_weight):
        """
        This function is initialized by the 'detect_changed' signal of self.weigher2;
        """
        self.new_order_flag = True
        if self.main_window_error_status and self.myconfig.data['operating_mode']['normal_error'] == '1':
            self.main_window.hideErrorInfo()
            self.main_window_error_status = False
        # if self.timer1.isActive() and self.transaction_not_end_status:
        #     self.timer1.start(180000)
        # self.media_player.player.setMedia(self.media_player.file06)
        # self.media_player.player.play()
        self.mylogging.logger.info(
            '------------------------------start a new ML calculation---------------------------------------------')
        self.record_weight = record_weight
        # print('weigher2_work4c_sherry begins')
        self.thread0_1.start()
        # print('weigher2_work4c_sherry ends')

    def sql_work5_sherry(self, result_sql):
        """
        To refresh my ShoppingList widget
        :param result_sql: a list of tuples;
        :return:
        """
        self.mylogging.logger.info('sql_work5_sherry begins')
        self.main_window.cleanCommodity()
        self.main_window.setSumPrice.emit('0')
        # with verification
        status_code, optimized_result_sql = self.verifyWeight3(current_weight=self.record_weight, result_sql=result_sql)
        if status_code == '0':
            # finding the optimized combination successfully;
            if self.reminder_weight_wrong_status:
                if self.myconfig.data['operating_mode']['weight_error'] == '1':
                    self.reminder_weight_wrong.setHidden(True)
                    self.reminder_weight_wrong_status = False
                if self.myconfig.data['operating_mode']['normal_error'] == '1':
                    self.main_window.hideErrorInfo()
                    self.main_window_error_status = False
            # Be careful the result_sql might be empty.
            if len(optimized_result_sql) == 0:
                self.mylogging.logger.info('sql_work5_sherry detects no item.')
                self.weigher.serial.readyRead.connect(self.weigher.acceptData_order)
            elif len(optimized_result_sql) >4:
                self.mylogging.logger.info('sql_work5_sherry detects more than 4 items')
                # self.media_player.player.setMedia(self.media_player.file09)
                # self.media_player.player.play()
                if self.myconfig.data['operating_mode']['normal_error'] == '1':
                    self.main_window.showErrorInfo(2)  # You need to hide it by yourself
                    self.main_window_error_status = True
                self.weigher.serial.readyRead.connect(self.weigher.acceptData_order)
            else:
                self.mylogging.logger.info('sql_work5_sherry starts to add items')
                sum = 0.0
                for index, item in enumerate(optimized_result_sql):
                    self.main_window.addCommodity(name=item[0], picName=str(item[3]), price=item[2])
                    sum = sum + float(item[2])
                self.main_window.setSumPrice.emit('%.2f' %sum)
                self.mylogging.logger.info('sql_work5_sherry ends to add items')
                self.thread6.dict01['weight'] = str(self.record_weight)
                self.thread6.dict01['buy_skuids'] = ','.join([str(product[3]) for product in optimized_result_sql])
                self.thread6.start()
        else:
            # for instance, all combination does not pass the verification;
            self.mylogging.logger.info('sql_work5_sherry: wrong verification of weight')
            # if the order number exists, set them to the default situation.
            self.thread0_1.last_result = []
            if self.order_number != 'invalid':
                self.order_number = 'invalid'
            media_status = self.media_player.player.mediaStatus()
            if media_status == QMediaPlayer.EndOfMedia or media_status == QMediaPlayer.NoMedia:
                self.media_player.player.setMedia(self.media_player.file10)
                self.media_player.player.play()
            # reminding the customer to place those item again
            self.reminder_weight_wrong.label1.setText('All combination fail.')
            if not self.reminder_weight_wrong_status:
                if self.myconfig.data['operating_mode']['weight_error'] == '1':
                    self.reminder_weight_wrong.setVisible(True)
                    self.reminder_weight_wrong_status = True
                if self.myconfig.data['operating_mode']['normal_error'] == '1':
                    self.main_window.showErrorInfo(0)
                    self.main_window_error_status = True
            # Be careful the result_sql might be empty.
            if len(result_sql) == 0:
                self.mylogging.logger.info('sql_work5_sherry detects no item.')
                if self.myconfig.data['operating_mode']['normal_error'] == '1':
                    self.main_window.showErrorInfo(0)
                    self.main_window_error_status = True
                self.weigher.serial.readyRead.connect(self.weigher.acceptData_order)
            elif len(result_sql) > 4:
                self.mylogging.logger.info('sql_work5_sherry detects more than 4 items')
                if self.myconfig.data['operating_mode']['normal_error'] == '1':
                    self.main_window.showErrorInfo(2)  # You need to hide it by yourself
                    self.main_window_error_status = True
                self.weigher.serial.readyRead.connect(self.weigher.acceptData_order)
            else:
                self.mylogging.logger.info('sql_work5_sherry starts to add items')
                sum = 0.0
                for index, item in enumerate(result_sql):
                    self.main_window.addCommodity(name=item[0], picName=str(item[3]), price=item[2])
                    sum = sum + float(item[2])
                self.main_window.setSumPrice.emit('%.2f' % sum)
                if self.myconfig.data['operating_mode']['normal_error'] == '1':
                    self.main_window.showErrorInfo(0)
                    self.main_window_error_status = True
                self.mylogging.logger.info('sql_work5_sherry ends to add items')
            self.weigher.serial.readyRead.connect(self.weigher.acceptData_order)

        self.mylogging.logger.info('sql_work5_sherry ends')

    def order_work8_sherry02(self, order_link):
        """
        :param order_link: if len(thread6.dict01['buy_skuids'])==0, the value of order_link is None; Otherwise, a string which is a link.
        :return:
        """
        self.mylogging.logger.info('order_work8_sherry02 begins')
        if order_link:
            self.order_link = order_link
            self.order_number = self.thread6.dict02['data']['order_no']
            self.main_window.setTradeNo(self.thread6.dict02['data']['order_no'])
            self.new_order_flag = False
            # self.media_player.player.setMedia(self.media_player.file11)
            # self.media_player.player.play()
        else:
            # when len(self.dict01['buy_skuids']) is equal to 0, the post_order_success will be False;
            self.order_number = 'invalid'
            self.new_order_flag = True
            if self.myconfig.data['operating_mode']['normal_error'] == '1':
                self.main_window.showErrorInfo(0)
                self.main_window_error_status = True
        self.weigher.serial.readyRead.connect(self.weigher.acceptData_order)
        self.mylogging.logger.info('order_work8_sherry02 ends')

    def weigher_work19_sherry(self):
        """
        To accelerate the process which is back to the standby layout;
        """
        self.mylogging.logger.info('weigher_work19_sherry begins')
        if self.timer1.isActive():
            self.timer1.start(10)  # unit is milli-second
        self.mylogging.logger.info('weigher_work19_sherry ends')

    def sql_work27_sherry(self, group_info_dict):
        """
        To refresh the group info dictionary 'self.group_info_dict' which will be used in verifyWeight3 function;
        :param group_info_dict:
        :return:
        """
        self.group_info_dict = group_info_dict

    def sysservice_work28_sherry(self):
        """
        to reconnect the database since there is a update;
        :return:
        """
        self.thread4.group_info_refresh_needed = True

    def sysservice_work29_sherry(self):
        """
        to reconnect the database since there is a update;
        :return:
        """
        self.thread4.database_update_needed = True

    def order_error04(self):
        """
        Error might happen in the QRcode thread.
        In normal situation,
        :return:
        """
        self.mylogging.logger.error('order_error04 begins')
        self.main_window.cleanCommodity()
        self.main_window.setSumPrice.emit('0')
        if self.myconfig.data['operating_mode']['normal_error'] == '1':
            self.main_window.showErrorInfo(1)
            self.main_window_error_status = True
        self.order_number = 'invalid'
        self.new_order_flag = True
        self.weigher.serial.readyRead.connect(self.weigher.acceptData_order)
        self.mylogging.logger.error('order_error04 ends')

    def sql_error05(self):
        """
        Error might happen in the SQL thread.
        For instance, the mysql connection is closed since there is no action to query the database over 8 hours.
        """
        self.mylogging.logger.error('sql_error05 begins')
        self.error_try_times_sql = self.error_try_times_sql + 1
        if self.error_try_times_sql < 10:
            self.main_window.cleanCommodity()
            self.main_window.setSumPrice.emit('0')
            self.order_number = 'invalid'
            self.new_order_flag = True
            self.weigher.serial.readyRead.connect(self.weigher.acceptData_order)
        else:
            if self.myconfig.data['operating_mode']['normal_error'] == '1':
                self.main_window.showErrorInfo(1)
                self.main_window_error_status = True
            self.mylogging.logger.error('Retry the sql thread but errors still exist.')
            # self.timer1.start(5*1000)
        self.mylogging.logger.error('sql_error05 ends')

    def sql_error06(self):
        """
        Other error might happen in the SQL thread.
        """
        self.mylogging.logger.error('sql_error06 begins')
        if self.myconfig.data['operating_mode']['normal_error'] == '1':
            self.main_window.showErrorInfo(1)
            self.main_window_error_status = True
        self.main_window.cleanCommodity()
        self.main_window.setSumPrice.emit('0')
        self.weigher.serial.readyRead.connect(self.weigher.acceptData_order)
        self.mylogging.logger.error('sql_error06 ends')

    def order_error07(self):
        """
        Error might happen in the order thread;
        For instance, the order number is none;
        """
        self.mylogging.logger.error('order_error07 begins')
        self.order_number = 'invalid'
        self.new_order_flag = True
        if self.myconfig.data['operating_mode']['normal_error'] == '1':
            self.main_window.showErrorInfo(1)
            self.main_window_error_status = True
        self.weigher.serial.readyRead.connect(self.weigher.acceptData_order)
        self.mylogging.logger.error('order_error07 ends')

    def verifyWeight3(self, current_weight, result_sql,
                      min_ratio=0.8, max_ratio=1.2,
                      group_id_index=-2, goods_weight_index=-3):
        """
        This function stays here due to logging statement;
        The group info dictionary is provided by self.group_info_dict;
        """
        sorted_result_sql = []
        # to reduce the calculation, one way is to sort the result based on the group_id;
        for item in result_sql:
            if item[group_id_index]:
                sorted_result_sql.append(item)
            else:
                sorted_result_sql.insert(0, item)
        result_sql = sorted_result_sql

        self.mylogging.logger.info('verifyWeight3 begins')
        self.mylogging.logger.info(result_sql)
        self.mylogging.logger.info('The current weight is %s' % current_weight)

        # calculating all combinations of detected items;
        all_possible_weight_dict = {'s': 0.0}  # s indicates 'sequence';
        max_weight = current_weight * max_ratio
        for index, item in enumerate(result_sql):
            newest_dict = {}
            item_group_id = item[group_id_index]
            # self.mylogging.logger.info('The data type of group id is %s.' % type(item_group_id))
            if item_group_id:
                # the group id is not None;
                group_info = self.group_info_dict.get(item_group_id)  # I am afraid there is no item information under the specific group id;
                if group_info:
                    # the group id exists and corresponding information exists;
                    for selection_index, one_item_record in enumerate(group_info):
                        selection_index_str = str(selection_index)
                        weight_increment = float(one_item_record[goods_weight_index])
                        for key in list(all_possible_weight_dict.keys()):
                            new_key = key + selection_index_str
                            # Be careful! the information stored in the last iteration dictionary should not be deleted;
                            # 1, save the possibility directly
                            # all_possible_weight_dict[new_key] = all_possible_weight_dict.pop(key) + weight_increment  # incorrect
                            # newest_dict[new_key] = all_possible_weight_dict[key] + weight_increment

                            # 2, reduce some possibility
                            new_key_weight = all_possible_weight_dict[key] + weight_increment
                            if new_key_weight < max_weight:
                                newest_dict[new_key] = new_key_weight
                    all_possible_weight_dict = newest_dict
                else:
                    # the group id exists but there is no corresponding information;
                    weight_increment = float(item[goods_weight_index])
                    for key in list(all_possible_weight_dict.keys()):
                        new_key = key + 'E'  # do not append 0 to the sequence of key since 0,1,2... are used when the group id is not None;
                        # Be careful! the information stored in the last iteration dictionary should not be deleted;
                        # 1, save the possibility directly
                        # all_possible_weight_dict[new_key] = all_possible_weight_dict.pop(key) + weight_increment  # incorrect
                        # newest_dict[new_key] = all_possible_weight_dict[key] + weight_increment

                        # 2, reduce some possibility
                        new_key_weight = all_possible_weight_dict[key] + weight_increment
                        if new_key_weight < max_weight:
                            newest_dict[new_key] = new_key_weight
                    all_possible_weight_dict = newest_dict
            else:
                # the group id is None;
                weight_increment = float(item[goods_weight_index])
                for key in list(all_possible_weight_dict.keys()):
                    new_key = key + 'N'  # do not append 0 to the sequence of key since 0,1,2... are used when the group id is not None;
                    # Be careful! the information stored in the last iteration dictionary should not be deleted;
                    # 1, save the possibility directly
                    # all_possible_weight_dict[new_key] = all_possible_weight_dict.pop(key) + weight_increment  # incorrect
                    # newest_dict[new_key] = all_possible_weight_dict[key] + weight_increment

                    # 2, reduce some possibility
                    new_key_weight = all_possible_weight_dict[key] + weight_increment
                    if new_key_weight < max_weight:
                        newest_dict[new_key] = new_key_weight
                all_possible_weight_dict = newest_dict

        # finding the optimized value;
        in_range_counter = 0
        optimized_key = 's'
        optimized_distance = current_weight
        if len(all_possible_weight_dict) > 0:
            min_weight = current_weight * min_ratio
            max_weight = current_weight * max_ratio
            for key, weight_value in all_possible_weight_dict.items():
                new_distance = abs(weight_value - current_weight)
                if min_weight < weight_value < max_weight:
                    if in_range_counter == 0:
                        optimized_distance = new_distance
                        optimized_key = key
                    elif optimized_distance > new_distance:
                        optimized_distance = new_distance
                        optimized_key = key
                    in_range_counter = in_range_counter + 1
            self.mylogging.logger.info('The optimized key is %s.' % optimized_key)
        else:
            self.mylogging.logger.info('There is no optimized key.')

        # restoring the final result of sql;
        final_result_sql = []
        status_code = '2'  # assuming that algorithm error happens
        if in_range_counter == 0:
            final_result_sql = result_sql  # Why is it not an empty list? My workmate need to know the result detected by model;
            status_code = '1'
            self.mylogging.logger.info('All combination of detected items do not pass the weight verification.')
        else:
            self.mylogging.logger.info('The optimized key passes the weight verification.')
            if len(optimized_key) == len(result_sql) + 1:
                for index, char in enumerate(optimized_key[1:]):
                    if char == 'N' or char == 'E':
                        final_result_sql.append(result_sql[index])
                    else:
                        item_group_id = result_sql[index][group_id_index]
                        final_result_sql.append(self.group_info_dict[item_group_id][int(char)])
                status_code = '0'
                self.mylogging.logger.info('The final result is %s.' % final_result_sql)
                self.mylogging.logger.info('The optimized distance is %s.' % optimized_distance)
            else:
                final_result_sql = result_sql  # Why is it not an empty list? My workmate need to know the result detected by model;
                status_code = '2'
                self.mylogging.logger.info('Algorithm error happens')

        self.mylogging.logger.info('verifyWeight3 ends')
        return status_code, final_result_sql

    def closeEvent(self, event):
        """
        This has unexpected outcome and the reason is not been discovered yet.
        """
        if self.myconfig.data['operating_mode']['weight_error'] == '1':
            dialog_status = self.camera_dialog.close()
            self.mylogging.logger.info('The camera item dialog closed with %s' % dialog_status)
        # self.main_widget.mainlayout.rightlayout.secondlayout.thread1.status = False  # The second way to stop the thread.
        # self.thread2.status = False
        # self.thread3.status = False
        self.weigher.serial.close()
        self.thread5.status = False
        self.thread7.status = False
        self.thread8.status = False
        self.thread4.conn.close()
        # self.thread0_0.status = False
        self.main_widget.mainlayout.rightlayout.secondlayout.capture0.release()
        self.capture1.release()


if __name__ == '__main__':
    app = QApplication(sys.argv)
    mainwindow = PaymentSystem_sherry()
    # mainwindow.show()
    sys.exit(app.exec_())

