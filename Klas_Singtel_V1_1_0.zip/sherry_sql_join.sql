use hobin;

#select goods_name, goods_spec, sku_price, sku_id, goods_weight, cv_id from storegoods where store_id = 2 order by sku_id;

# insert into cm_cvid_group_bind (sku_id, group_id) values (309, 2);
#insert into cm_cvid_group_bind (sku_id, group_id) values (413, 3);
#delete from cm_cvid_group_bind where group_id= 2 and sku_id in (140);
select * from cm_cvid_group_bind order by group_id;

# select distinct a.store_id from storegoods as a;

#select goods_name, goods_spec, sku_price, sku_id, goods_weight, cv_id from storegoods order by cv_id;

select a.goods_name, a.goods_spec, a.sku_price, a.sku_id, a.goods_weight, b.group_id, a.cv_id from storegoods as a 
left join cm_cvid_group_bind as b on a.sku_id= b.sku_id 
where a.cv_id in (460, 460, 589, 589, 3976, 285) and a.store_id= 2 order by a.cv_id;

select a.goods_name, a.goods_spec, a.sku_price, a.sku_id, a.goods_weight, b.group_id, a.cv_id from storegoods as a 
right join cm_cvid_group_bind as b on a.sku_id= b.sku_id 
where a.store_id = 2 order by group_id;


/*
select a.goods_name, a.sku_id, b.group_id, a.cv_id from storegoods as a 
inner join cm_cvid_group_bind as b on a.sku_id= b.sku_id
where a.cv_id in (460, 460, 589);
*/


