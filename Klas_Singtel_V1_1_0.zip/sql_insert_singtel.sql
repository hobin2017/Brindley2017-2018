use hobin;

#select * from storegoods where store_id =2 and cv_id in (1);


insert into storegoods (cv_id, sku_id, sku_price, sku_name, goods_spec, goods_name, goods_weight)
values (152344, 1519, '10.0', 'calbee potato chips barbecue', 'goods_spec: 2', 'goods_name: 3', '91');

#select * from storegoods where cv_id = 152344;

#delete from storegoods where cv_id = 152344;

#select * from storegoods where cv_id in (152344, 152346, 152347);


